package practica_poo02;

//Clase para guardar los desperfectos luminarios
public class Luminaria extends Desperfecto {

	public Luminaria(String nombre, double precio, int cantidad) {
		super(nombre, precio, cantidad, precio);
	}
}
