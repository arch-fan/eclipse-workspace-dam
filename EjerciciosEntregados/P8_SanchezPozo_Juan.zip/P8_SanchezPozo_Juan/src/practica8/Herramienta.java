package practica8;

public class Herramienta {
    private final String nombre;

    public Herramienta(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
